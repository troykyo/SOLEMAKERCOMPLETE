const bcrypt = require('bcrypt-nodejs');
const crypto = require('crypto');
const mongoose = require('mongoose');

const sessionSchema = new mongoose.Schema({
	acquired: Date,
	data: Buffer,
	description: String,
	email: String,
	activationURL: String,
	activated: Boolean

}, { timestamps: true });

/**
 * Password hash middleware.
 */
sessionSchema.pre('save', function (next) {
  const user = this;
  if (!user.isModified('email')) { return next(); }
  const md5 = crypto.createHash('md5').update(this.email).digest('hex');
  user.activationURL = `https://gravatar.com/avatar/${md5}`;
  next();
});


const RecordingSession = mongoose.model('RecordingSession', sessionSchema);

module.exports = RecordingSession;
