/**
 * GET /make
 * Sole Editor Home page.
 */
exports.index = (req, res) => {
  res.render('make', {
    title: 'Make'
  });
};
