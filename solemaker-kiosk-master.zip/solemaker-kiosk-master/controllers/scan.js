/**
 * GET /scan
 * Sole Scanner Record Session Home page.
 */
exports.index = (req, res) => {
  res.render('scan/upload', {
    title: 'Scan'
  });
};



exports.postFileUpload = (req, res, next) => {
  req.flash('success', { msg: 'File was uploaded successfully.' });
  res.redirect('/scan/review');
};


exports.getReview = (req,res, next) => {
  res.render('scan/review', {
      title: 'Review scan'
  });
};

exports.postReview = (req,res, next) => {
    req.flash('success', { msg: 'Generating receipt.'});
    res.redirect('/scan/receipt');
};

exports.getReceipt = (req,res,next) => {
  res.render('scan/receipt', {
      title: 'Scan receipt'
  });
};