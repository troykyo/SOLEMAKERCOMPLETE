module.exports = function(grunt) {
  grunt.initConfig({
    eslint: {
      client: {
        src: ['public/js/**/*.js'],
        options: {
          configFile:'conf/eslint.json',
          fix: true,
          rulesDir:"conf/rules"
        }
      }
    },
    less: {
      client: {
        files: {
          'build/css/all.css':'public/**/*.less'
        }
      }
    },
    concat: {
      client: {
        src:['public/js/**/*.js'],
        dest:'tmp/all.js'
      }
    },
    browserify: {
      client: {
        options: {
          transform: [['babelify', {presets:['es2015','react']}]]
        },
        src:['tmp/all.js'],
        dest:'build/js/all.js'
      }
    },
    watch: {
      js: {
        files: ['public/js/**/*.js'],
        tasks: ['eslint:client','concat:client','browserify:client']
      },
      less: {
        files: ['public/**/*.less'],
        tasks: ['less:client']
      },
      html: {
        files: ['index.html'],
        tasks: ["less:client"]
      },
      rebuild: {
        files: ['Gruntfile.js'],
        tasks: ['eslint:client','build:client']
      },
      livereload: {
        options: {
          livereload: true
        },
        files: ['build/**/*.{css,js,html}','index.html']
      }
    }
  });

  grunt.loadNpmTasks('grunt-contrib-concat');
  grunt.loadNpmTasks('grunt-contrib-watch');
  grunt.loadNpmTasks('grunt-contrib-copy');
  grunt.loadNpmTasks('grunt-contrib-less');
  grunt.loadNpmTasks('grunt-conventional-changelog');
  grunt.loadNpmTasks('grunt-browserify');
  grunt.loadNpmTasks('grunt-babel');
  grunt.loadNpmTasks('grunt-bump');
  grunt.loadNpmTasks('gruntify-eslint');


  grunt.registerTask('build:client',"Lint and compile",[''])
  grunt.registerTask('default','default task',[
    'less:client',
    'eslint:client',
    'concat:client',
    'browserify:client'
  ]);
}
