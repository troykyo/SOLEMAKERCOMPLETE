var sole_design = {
  inset: 2
};
