SoleMaker web app

# TODO FOR DDW
* Outline scaling based on sensor data
* Debugging visualization delays
* FPS frame dropout
* Rescaling preprocessing
  * Unit outline (mapped from 0 to 1)
  * 
* Drawing a better outline

Built for:
Troy Nachtigall

# Functionalities
* Web based User interface (_Work in progress_)
* Sole outline import (**TODO**)
* Sole outline editor (_DONE_)
* Voronoi Seeds editor (_DONE_)
* Voronoi Shoe-sole design algorithm (_DONE_)
* Voronoi polygon generator (_DONE_)
* Voronoi polygon cutoff (**DEBUG!**)
* Voronoi polygon inset (**DEBUG!**)
* Shoe-sole design to g-code (**TODO**)
* Traveling salesman pathfinder (**TODO**)
* Chinese postman pathfinder (**TODO**)
* g-code exporter (**TODO**)

#Technical specification of terminology
**User inputs**
* Sole Outline (= array of (x,y) points)
* Voronoi Seeds (= array of (x, y) points)

_**Voronoi shoe sole design algorithm**_

Converts Sole Outline & Voronoi Seeds to inset voronoi polygons cut off by the sole outline

**Shoe sole design**
* Sole outline
* Inset voronoi polygons cut off by the sole outline ( = array of polygons, each polygon is an array
of (x,y) points.)

_**Sole design to g-code algorithm**_

Converts the sole design to the g-code path for 3D printing the shoes

**Shoe sole Manufacturing file**
* G-Code path (= array of (x,y) points with speed parameter)
